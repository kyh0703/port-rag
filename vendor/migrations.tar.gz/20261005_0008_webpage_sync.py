"""Persist webpage synchronization and immutable live-source membership.

Revision ID: 20261005_0008
Revises: 20261001_0007
Create Date: 2026-10-05 00:00:00.000000
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "20261005_0008"
down_revision: str | None = "20261001_0007"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "document_webpages",
        sa.Column("document_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("urls", postgresql.JSONB(), nullable=False),
        sa.Column("auto_sync", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("sync_status", sa.String(16), nullable=False, server_default="queued"),
        sa.Column("queue_reason", sa.String(16), nullable=False, server_default="initial"),
        sa.Column("content", sa.Text(), nullable=False, server_default=""),
        sa.Column("content_hash", sa.String(64)),
        sa.Column("last_synced_at", sa.DateTime(timezone=True)),
        sa.Column("last_checked_at", sa.DateTime(timezone=True)),
        sa.Column("next_sync_at", sa.DateTime(timezone=True)),
        sa.Column("sync_error", sa.Text()),
        sa.Column("last_sync_changed", sa.Boolean()),
        sa.Column("claim_token", postgresql.UUID(as_uuid=True)),
        sa.Column("claimed_at", sa.DateTime(timezone=True)),
        sa.PrimaryKeyConstraint("document_id"),
        sa.ForeignKeyConstraint(["document_id"], ["documents.id"], ondelete="CASCADE"),
        sa.CheckConstraint("sync_status IN ('idle', 'queued', 'running', 'failed')",
                           name="ck_document_webpages_sync_status"),
        sa.CheckConstraint("jsonb_typeof(urls) = 'array' AND jsonb_array_length(urls) BETWEEN 1 AND 100",
                           name="ck_document_webpages_urls"),
        sa.CheckConstraint("queue_reason IN ('initial', 'manual', 'automatic')",
                           name="ck_document_webpages_queue_reason"),
        sa.CheckConstraint("(sync_status = 'running') = (claim_token IS NOT NULL AND claimed_at IS NOT NULL)",
                           name="ck_document_webpages_claim"),
        sa.CheckConstraint("auto_sync OR next_sync_at IS NULL", name="ck_document_webpages_schedule"),
    )
    op.create_index("ix_document_webpages_due", "document_webpages", ["next_sync_at"],
                    postgresql_where=sa.text("auto_sync = true"))
    op.create_index("ix_document_webpages_queue", "document_webpages", ["sync_status", "claimed_at"])
    op.execute("""
        CREATE TRIGGER rag_webpage_owner_admission
        BEFORE INSERT OR UPDATE ON public.document_webpages
        FOR EACH ROW EXECUTE FUNCTION public.rag_chunk_owner_admission()
    """)
    # Deliberately no source-document FK: membership is immutable after publication.
    # Search inner-joins current, same-owner, ready sources; deletion yields no content.
    op.create_table(
        "knowledge_revision_webpages",
        sa.Column("revision_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("document_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.PrimaryKeyConstraint("revision_id", "document_id"),
        sa.ForeignKeyConstraint(["revision_id"], ["knowledge_revisions.id"], ondelete="RESTRICT"),
    )
    op.execute("""
        CREATE FUNCTION public.rag_revision_webpage_admission()
        RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        DECLARE
          v_owner uuid;
        BEGIN
          SELECT user_id INTO v_owner FROM public.knowledge_revisions WHERE id = NEW.revision_id;
          PERFORM public.rag_assert_owner_active(v_owner);
          IF NOT EXISTS (
            SELECT 1 FROM public.documents d
            JOIN public.document_webpages w ON w.document_id = d.id
            WHERE d.id = NEW.document_id AND d.user_id = v_owner AND d.status = 'ready'
          ) THEN
            RAISE EXCEPTION 'live webpage must be a ready document owned by the revision owner';
          END IF;
          RETURN NEW;
        END;
        $$
    """)
    op.execute("""
        CREATE TRIGGER rag_revision_webpage_admission
        BEFORE INSERT ON public.knowledge_revision_webpages
        FOR EACH ROW EXECUTE FUNCTION public.rag_revision_webpage_admission()
    """)
    op.execute("""
        CREATE FUNCTION public.knowledge_revision_webpages_are_immutable()
        RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        BEGIN
          IF TG_OP = 'DELETE' AND EXISTS (
            SELECT 1 FROM public.rag_account_erasure_context AS e
            JOIN public.knowledge_revisions AS r
              ON e.owner_hash = encode(sha256(convert_to(r.user_id::text, 'UTF8')), 'hex')
            WHERE e.transaction_id = txid_current() AND r.id = OLD.revision_id
          ) THEN
            RETURN OLD;
          END IF;
          RAISE EXCEPTION 'knowledge revision webpage membership is immutable';
        END;
        $$
    """)
    op.execute("""
        CREATE TRIGGER knowledge_revision_webpages_are_immutable
        BEFORE UPDATE OR DELETE ON public.knowledge_revision_webpages
        FOR EACH ROW EXECUTE FUNCTION public.knowledge_revision_webpages_are_immutable()
    """)
    # Preserve erasure authority/isolation and existing frozen-row triggers verbatim;
    # only add deletion of the newly introduced owned membership before its parent.
    op.execute("""
        CREATE OR REPLACE FUNCTION public.rag_erase_user_data(p_user_id uuid)
        RETURNS void LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        DECLARE
          v_hash text := encode(sha256(convert_to(p_user_id::text, 'UTF8')), 'hex');
        BEGIN
          IF current_setting('transaction_isolation') <> 'read committed' THEN
            RAISE EXCEPTION 'rag owner operations require READ COMMITTED isolation'
              USING ERRCODE = '0A000';
          END IF;
          PERFORM public.rag_fence_owner_erasure(p_user_id);
          INSERT INTO public.rag_account_erasure_context(transaction_id, owner_hash)
          VALUES (txid_current(), v_hash);
          DELETE FROM public.knowledge_revision_webpages AS w
          USING public.knowledge_revisions AS r
          WHERE w.revision_id = r.id AND r.user_id = p_user_id;
          DELETE FROM public.knowledge_revision_chunks AS c
          USING public.knowledge_revisions AS r
          WHERE c.revision_id = r.id AND r.user_id = p_user_id;
          DELETE FROM public.knowledge_revisions WHERE user_id = p_user_id;
          DELETE FROM public.documents WHERE user_id = p_user_id;
          DELETE FROM public.rag_account_erasure_context
          WHERE transaction_id = txid_current() AND owner_hash = v_hash;
        END;
        $$
    """)


def downgrade() -> None:
    raise RuntimeError("Live webpage memberships and erasure authority require forward-only recovery")
