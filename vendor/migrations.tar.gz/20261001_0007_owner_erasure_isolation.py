"""Require fresh READ COMMITTED snapshots for owner-erasure authority.

Revision ID: 20261001_0007
Revises: 20261001_0006
Create Date: 2026-10-01 00:00:00.000000
"""

from collections.abc import Sequence

from alembic import op

revision: str = "20261001_0007"
down_revision: str | None = "20261001_0006"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    # Advisory locks serialize owners, but cannot refresh a Repeatable Read or
    # Serializable snapshot taken before the durable erased-owner fence.
    # Replacing the existing routines preserves their execution privileges.
    op.execute("""
        CREATE OR REPLACE FUNCTION public.rag_assert_owner_active(p_user_id uuid)
        RETURNS void LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        BEGIN
          IF p_user_id IS NULL THEN
            RAISE EXCEPTION 'rag owner is required' USING ERRCODE = '22004';
          END IF;
          IF current_setting('transaction_isolation') <> 'read committed' THEN
            RAISE EXCEPTION 'rag owner operations require READ COMMITTED isolation'
              USING ERRCODE = '0A000';
          END IF;
          PERFORM pg_advisory_xact_lock(hashtextextended('rag-owner:' || p_user_id::text, 0));
          IF EXISTS (
            SELECT 1 FROM public.rag_erased_owners
            WHERE owner_hash = encode(sha256(convert_to(p_user_id::text, 'UTF8')), 'hex')
          ) THEN
            RAISE EXCEPTION 'rag owner data erased' USING ERRCODE = '55000';
          END IF;
        END;
        $$
    """)
    op.execute("""
        CREATE OR REPLACE FUNCTION public.rag_fence_owner_erasure(p_user_id uuid)
        RETURNS void LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        BEGIN
          IF p_user_id IS NULL THEN
            RAISE EXCEPTION 'rag owner is required' USING ERRCODE = '22004';
          END IF;
          IF current_setting('transaction_isolation') <> 'read committed' THEN
            RAISE EXCEPTION 'rag owner operations require READ COMMITTED isolation'
              USING ERRCODE = '0A000';
          END IF;
          PERFORM pg_advisory_xact_lock(hashtextextended('rag-owner:' || p_user_id::text, 0));
          INSERT INTO public.rag_erased_owners(owner_hash)
          VALUES (encode(sha256(convert_to(p_user_id::text, 'UTF8')), 'hex'))
          ON CONFLICT (owner_hash) DO NOTHING;
        END;
        $$
    """)
    op.execute("""
        CREATE OR REPLACE FUNCTION public.rag_erase_user_data(p_user_id uuid)
        RETURNS void LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        DECLARE
          v_hash text := encode(sha256(convert_to(p_user_id::text, 'UTF8')), 'hex');
        BEGIN
          IF current_setting('transaction_isolation') <> 'read committed' THEN
            RAISE EXCEPTION 'rag owner operations require READ COMMITTED isolation'
              USING ERRCODE = '0A000';
          END IF;
          PERFORM public.rag_fence_owner_erasure(p_user_id);
          INSERT INTO public.rag_account_erasure_context(transaction_id, owner_hash)
          VALUES (txid_current(), v_hash);
          DELETE FROM public.knowledge_revision_chunks AS c
          USING public.knowledge_revisions AS r
          WHERE c.revision_id = r.id AND r.user_id = p_user_id;
          DELETE FROM public.knowledge_revisions WHERE user_id = p_user_id;
          DELETE FROM public.documents WHERE user_id = p_user_id;
          DELETE FROM public.rag_account_erasure_context
          WHERE transaction_id = txid_current() AND owner_hash = v_hash;
        END;
        $$
    """)


def downgrade() -> None:
    raise RuntimeError("Owner-erasure isolation enforcement cannot be safely downgraded")
