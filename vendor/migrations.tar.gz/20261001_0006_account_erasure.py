"""Fence erased owners and narrowly authorize account-owned immutable erasure.

Revision ID: 20261001_0006
Revises: 20260827_0005
Create Date: 2026-10-01 00:00:00.000000
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "20261001_0006"
down_revision: str | None = "20260827_0005"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "rag_erased_owners",
        sa.Column("owner_hash", sa.String(64), nullable=False),
        sa.CheckConstraint("owner_hash ~ '^[0-9a-f]{64}$'", name="ck_rag_erased_owner_hash"),
        sa.PrimaryKeyConstraint("owner_hash"),
    )
    # This transaction-local authorization row is removed before a successful
    # routine returns, or rolled back on failure. It never stores source content.
    op.create_table(
        "rag_account_erasure_context",
        sa.Column("transaction_id", sa.BigInteger(), nullable=False),
        sa.Column("owner_hash", sa.String(64), nullable=False),
        sa.ForeignKeyConstraint(["owner_hash"], ["rag_erased_owners.owner_hash"]),
        sa.PrimaryKeyConstraint("transaction_id"),
    )
    op.execute("REVOKE ALL ON public.rag_erased_owners FROM PUBLIC")
    op.execute("REVOKE ALL ON public.rag_account_erasure_context FROM PUBLIC")
    op.execute("""
        CREATE FUNCTION public.rag_assert_owner_active(p_user_id uuid)
        RETURNS void LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        BEGIN
          IF p_user_id IS NULL THEN
            RAISE EXCEPTION 'rag owner is required' USING ERRCODE = '22004';
          END IF;
          PERFORM pg_advisory_xact_lock(hashtextextended('rag-owner:' || p_user_id::text, 0));
          IF EXISTS (
            SELECT 1 FROM public.rag_erased_owners
            WHERE owner_hash = encode(sha256(convert_to(p_user_id::text, 'UTF8')), 'hex')
          ) THEN
            RAISE EXCEPTION 'rag owner data erased' USING ERRCODE = '55000';
          END IF;
        END;
        $$
    """)
    op.execute("""
        CREATE FUNCTION public.rag_fence_owner_erasure(p_user_id uuid)
        RETURNS void LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        BEGIN
          IF p_user_id IS NULL THEN
            RAISE EXCEPTION 'rag owner is required' USING ERRCODE = '22004';
          END IF;
          PERFORM pg_advisory_xact_lock(hashtextextended('rag-owner:' || p_user_id::text, 0));
          INSERT INTO public.rag_erased_owners(owner_hash)
          VALUES (encode(sha256(convert_to(p_user_id::text, 'UTF8')), 'hex'))
          ON CONFLICT (owner_hash) DO NOTHING;
        END;
        $$
    """)
    op.execute("REVOKE ALL ON FUNCTION public.rag_fence_owner_erasure(uuid) FROM PUBLIC")
    op.execute("""
        CREATE FUNCTION public.rag_erase_user_data(p_user_id uuid)
        RETURNS void LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        DECLARE
          v_hash text := encode(sha256(convert_to(p_user_id::text, 'UTF8')), 'hex');
        BEGIN
          PERFORM public.rag_fence_owner_erasure(p_user_id);
          INSERT INTO public.rag_account_erasure_context(transaction_id, owner_hash)
          VALUES (txid_current(), v_hash);
          DELETE FROM public.knowledge_revision_chunks AS c
          USING public.knowledge_revisions AS r
          WHERE c.revision_id = r.id AND r.user_id = p_user_id;
          DELETE FROM public.knowledge_revisions WHERE user_id = p_user_id;
          DELETE FROM public.documents WHERE user_id = p_user_id;
          DELETE FROM public.rag_account_erasure_context
          WHERE transaction_id = txid_current() AND owner_hash = v_hash;
        END;
        $$
    """)
    op.execute("REVOKE ALL ON FUNCTION public.rag_erase_user_data(uuid) FROM PUBLIC")
    op.execute("""
        CREATE OR REPLACE FUNCTION public.knowledge_revision_rows_are_immutable()
        RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        BEGIN
          IF TG_OP = 'DELETE' AND EXISTS (
            SELECT 1 FROM public.rag_account_erasure_context
            WHERE transaction_id = txid_current()
              AND owner_hash = encode(sha256(convert_to(OLD.user_id::text, 'UTF8')), 'hex')
          ) THEN
            RETURN OLD;
          END IF;
          RAISE EXCEPTION 'knowledge revisions are immutable';
        END;
        $$
    """)
    op.execute("""
        CREATE OR REPLACE FUNCTION public.knowledge_revision_chunks_are_immutable()
        RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        BEGIN
          IF TG_OP = 'DELETE' AND EXISTS (
            SELECT 1 FROM public.rag_account_erasure_context AS e
            JOIN public.knowledge_revisions AS r
              ON e.owner_hash = encode(sha256(convert_to(r.user_id::text, 'UTF8')), 'hex')
            WHERE e.transaction_id = txid_current() AND r.id = OLD.revision_id
          ) THEN
            RETURN OLD;
          END IF;
          RAISE EXCEPTION 'knowledge revision chunks are immutable';
        END;
        $$
    """)
    op.execute("""
        CREATE FUNCTION public.rag_document_owner_admission()
        RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        BEGIN
          IF TG_OP = 'UPDATE' THEN
            PERFORM public.rag_assert_owner_active(OLD.user_id);
          END IF;
          PERFORM public.rag_assert_owner_active(NEW.user_id);
          RETURN NEW;
        END;
        $$
    """)
    op.execute("""
        CREATE TRIGGER rag_document_owner_admission
        BEFORE INSERT OR UPDATE ON public.documents
        FOR EACH ROW EXECUTE FUNCTION public.rag_document_owner_admission()
    """)
    op.execute("""
        CREATE FUNCTION public.rag_chunk_owner_admission()
        RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        DECLARE
          v_owner uuid;
        BEGIN
          IF TG_OP = 'UPDATE' THEN
            SELECT user_id INTO v_owner FROM public.documents WHERE id = OLD.document_id;
            PERFORM public.rag_assert_owner_active(v_owner);
          END IF;
          SELECT user_id INTO v_owner FROM public.documents WHERE id = NEW.document_id;
          PERFORM public.rag_assert_owner_active(v_owner);
          RETURN NEW;
        END;
        $$
    """)
    op.execute("""
        CREATE TRIGGER rag_chunk_owner_admission
        BEFORE INSERT OR UPDATE ON public.chunks
        FOR EACH ROW EXECUTE FUNCTION public.rag_chunk_owner_admission()
    """)
    op.execute("""
        CREATE FUNCTION public.rag_revision_owner_admission()
        RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        BEGIN
          PERFORM public.rag_assert_owner_active(NEW.user_id);
          RETURN NEW;
        END;
        $$
    """)
    op.execute("""
        CREATE TRIGGER rag_revision_owner_admission
        BEFORE INSERT ON public.knowledge_revisions
        FOR EACH ROW EXECUTE FUNCTION public.rag_revision_owner_admission()
    """)
    op.execute("""
        CREATE FUNCTION public.rag_revision_chunk_owner_admission()
        RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog, public AS $$
        DECLARE
          v_owner uuid;
        BEGIN
          SELECT user_id INTO v_owner FROM public.knowledge_revisions WHERE id = NEW.revision_id;
          PERFORM public.rag_assert_owner_active(v_owner);
          RETURN NEW;
        END;
        $$
    """)
    op.execute("""
        CREATE TRIGGER rag_revision_chunk_owner_admission
        BEFORE INSERT ON public.knowledge_revision_chunks
        FOR EACH ROW EXECUTE FUNCTION public.rag_revision_chunk_owner_admission()
    """)


def downgrade() -> None:
    raise RuntimeError("Account erasure is irreversible; retain the erased-owner fence")
